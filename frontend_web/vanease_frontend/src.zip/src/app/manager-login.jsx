"use client"

import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useUserContext } from "../context/UserContext"
import api from "../utils/axiosConfig"
import { toast } from "react-toastify"
import "../styles/login.css"

export default function ManagerLogin() {
  const navigate = useNavigate()
  const { login } = useUserContext()
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      const response = await api.post("/auth/login", formData)
      const { token, role } = response.data

      if (role !== "ROLE_MANAGER") {
        setError("Access denied. This login is for managers only.")
        toast.error("Access denied. This login is for managers only.")
        return
      }

      // Use the login function from context
      login(token)
      toast.success("Login successful!")
      navigate("/manager-dashboard")
    } catch (err) {
      console.error("Error during login:", err)
      setError(err.response?.data || "Login failed. Please try again.")
      toast.error(err.response?.data || "Login failed. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="login-header">
          <h1>Manager Login</h1>
          <p>Welcome back! Please log in to your account.</p>
        </div>

        {error && <div className="error-message">{error}</div>}

        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
              placeholder="Enter your email"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
              placeholder="Enter your password"
            />
          </div>

          <button type="submit" className="login-button" disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>
      </div>
    </div>
  )
}
