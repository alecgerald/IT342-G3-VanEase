import React, { useEffect, useRef } from 'react';
import api from '../utils/axiosConfig';

const PayPalButton = ({ bookingId, onSuccess, onError }) => {
    const paypalRef = useRef(null);
    const buttonContainerRef = useRef(null);
    let paypalInstance = null;

    const loadPayPalScript = async () => {
        try {
            // Clear any existing PayPal buttons
            if (buttonContainerRef.current) {
                buttonContainerRef.current.innerHTML = '';
            }

            // Load PayPal script with PHP currency
            const script = document.createElement('script');
            script.src = `https://www.paypal.com/sdk/js?client-id=Ac-rel7bo3zhF_Rn-lA2oOWtEKDIr3pHCR7cW4J1gWSEaq0sMcws2leDT8ruu3XthtzVoJr4HTb3Gcvi&currency=PHP`;
            script.async = true;

            script.onload = () => {
                if (window.paypal && buttonContainerRef.current) {
                    paypalInstance = window.paypal.Buttons({
                        style: {
                            layout: 'vertical',
                            color: 'blue',
                            shape: 'rect',
                            label: 'paypal'
                        },
                        createOrder: async () => {
                            try {
                                const response = await api.post('/paypal/create-order', {
                                    bookingId: bookingId
                                });
                                return response.data.orderId;
                            } catch (err) {
                                console.error('Error creating PayPal order:', err);
                                onError(err);
                                throw err;
                            }
                        },
                        onApprove: async (data) => {
                            try {
                                const response = await api.post(`/paypal/capture-order/${data.orderID}?bookingId=${bookingId}`);
                                onSuccess(response.data);
                            } catch (err) {
                                console.error('Error capturing PayPal payment:', err);
                                onError(err);
                            }
                        },
                        onError: (err) => {
                            console.error('PayPal button error:', err);
                            onError(err);
                        }
                    });

                    paypalInstance.render(buttonContainerRef.current).catch(err => {
                        console.error('Error rendering PayPal button:', err);
                        onError(err);
                    });
                }
            };

            script.onerror = () => {
                console.error('Error loading PayPal script');
                onError(new Error('Failed to load PayPal'));
            };

            document.body.appendChild(script);

            return () => {
                if (paypalInstance) {
                    try {
                        paypalInstance.close();
                    } catch (err) {
                        console.error('Error closing PayPal instance:', err);
                    }
                }
                if (script.parentNode) {
                    script.parentNode.removeChild(script);
                }
            };
        } catch (err) {
            console.error('Error in PayPal button setup:', err);
            onError(err);
        }
    };

    useEffect(() => {
        if (!bookingId) {
            console.error('Booking ID is required for PayPal payment');
            onError(new Error('Booking ID is required'));
            return;
        }

        loadPayPalScript();

        return () => {
            if (paypalInstance) {
                try {
                    paypalInstance.close();
                } catch (err) {
                    console.error('Error closing PayPal instance:', err);
                }
            }
        };
    }, [bookingId]);

    if (!bookingId) {
        return <div>Error: Booking ID is required</div>;
    }

    return (
        <div className="paypal-button-wrapper">
            <div ref={buttonContainerRef} id="paypal-button-container" />
        </div>
    );
};

export default PayPalButton; 